package com.mega.mobile07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button b1, b2;
    EditText tourName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.b1); // 이동
        b2 = findViewById(R.id.b2); // 초기화
        tourName = findViewById(R.id.tourName);


        b1.setOnClickListener(this);
        b2.setOnClickListener(this);


        // 리팩토링 전 코드
//        b1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//               String tour = tourName.getText().toString();
//                //Toast.makeText(getApplicationContext(), "입력받은 값은" + tour, Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
//                intent.putExtra("tourName", tour);
//                startActivity(intent);
//            }
//        });
    } // onCreate

    @Override
    public void onClick(View view) {
        String who = "";
        if (view.getId() == R.id.b1) { // 버튼 구분
            who = "b1Button";
        } else {
            who = "b2Button";
        } // else end

        String tour = tourName.getText().toString();
        //Toast.makeText(getApplicationContext(), "입력받은 값은" + tour, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra("tourName", tour);
        intent.putExtra("who", who);
        startActivity(intent);
    }// onclick end
} //Main end