package com.mega.mobile07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    Button confirm, siteGo;
    EditText s;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3); // 인플레이션(기능의 증대) - 레이아웃과 뷰를 합쳐줌
        setTitle("activity3~");

        confirm = findViewById(R.id.confirm); // 확인 버튼
        siteGo = findViewById(R.id.siteGo); // 이동 버튼
        s = findViewById(R.id.s); // 에디트 텍스트

        // 앞에서 입력한 데이터를 받아오기
        Intent intent = getIntent();
        String siteName = intent.getStringExtra("siteName");
        // 받아오자마자 toast로 확인, toast 함수 만들기
        //받아온 데이터를 가지고, 대표적인 사이트로 연결 (goSite 함수를 만들어서 호출)
        //입력란을 만들어서, 해당 사이트로 연결 (goSite 함수 호출)
        //goSite 함수 안에는 "넘어갑니다 @@@@@"


        // 4번
//        confirm.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String site ="";
//                if(siteName.equals("산")){
//                site = "https://terms.naver.com/entry.naver?docId=572816&cid=46617&categoryId=46617";
//                } else if (siteName.equals("바다")){
//                    site = "https://namu.wiki/w/%EB%B0%94%EB%8B%A4";
//                } else {
//                    site = "https://terms.naver.com/entry.naver?docId=1083091&cid=40942&categoryId=33136";
//                }
//                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(site));
//                startActivity(intent);
//            }
//        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String siteName = s.getText().toString();
                //goSite(siteName);
                toast(siteName);
            }
        });

        siteGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //입력값을 가지고 와서
                String siteName = s.getText().toString();
                // go Site()
                goSite(siteName);
                toast(siteName +"로 넘어갑니다 @@@@@@@@@@");
            }
        });

    } // onCreate

    public void goSite(String siteName) {
        String site ="";
        if(siteName.equals("산")){
            site = "https://terms.naver.com/entry.naver?docId=572816&cid=46617&categoryId=46617";
        } else if (siteName.equals("바다")){
            site = "https://namu.wiki/w/%EB%B0%94%EB%8B%A4";
        } else {
            site = "https://terms.naver.com/entry.naver?docId=1083091&cid=40942&categoryId=33136";
        }
        Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(site));
        startActivity(intent);
    }

    public void toast(String site) {
        Toast.makeText(getApplicationContext(), "이동할 곳은 " + site, Toast.LENGTH_SHORT).show();
    }
}