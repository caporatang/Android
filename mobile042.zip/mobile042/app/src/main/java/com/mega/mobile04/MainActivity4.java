package com.mega.mobile04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
    Button b1, b2, b3; //전역 변수, null로 자동 초기화



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "페이지2로 넘어 갑니다",
                        Toast.LENGTH_SHORT).show(); // 체인식 코드
                //화면 넘겨주는 객체를 생성해주어야 한다.
                // 생성자(현재 액티비티, 넘어갈 액티비티)를 사용한다
                Intent intent = new Intent(MainActivity4.this, Page2.class);
                                                            //엑티비티에 this(시작점) , 넘어갈 페이지.class
                startActivity(intent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "3페이지로 넘어갑니다",
                        Toast.LENGTH_SHORT).show();
                //화면 이동 객체 생성
                Intent intent = new Intent(MainActivity4.this, Page3.class);
             startActivity(intent);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //토스트 띄우기
                Toast.makeText(getApplicationContext(), "Start페이지를 종료합니다",
                        Toast.LENGTH_SHORT).show(); // 체인식 코드
                finish();

            }
        });


    }
}