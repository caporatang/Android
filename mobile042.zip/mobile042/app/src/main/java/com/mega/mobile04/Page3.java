package com.mega.mobile04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Page3 extends AppCompatActivity {
    Button b7, b8, b9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);

        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);
        b9 = findViewById(R.id.button9);

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Start페이지로 이동",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Page3.this, MainActivity4.class);
                startActivity(intent);
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "2페이지로 이동",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Page3.this, Page2.class);
                startActivity(intent);
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //토스트 띄우기
                Toast.makeText(getApplicationContext(), "page3을 종료합니다",
                        Toast.LENGTH_SHORT).show(); // 체인식 코드
                finish();

            }
        });


    }
}