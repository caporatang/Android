package com.mega.mobile04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Page2 extends AppCompatActivity {
    Button b4, b5, b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Start 페이지로 이동",
                        Toast.LENGTH_SHORT).show();
                //화면 이동객체 Intent 생성
                Intent intent = new Intent(Page2.this, MainActivity4.class);
                startActivity(intent);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "3페이지로 이동",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Page2.this, Page3.class);
                startActivity(intent);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //토스트 띄우기
                Toast.makeText(getApplicationContext(), "page2를 종료합니다",
                        Toast.LENGTH_SHORT).show(); // 체인식 코드
                finish();

            }
        });


    }
}