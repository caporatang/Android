package com.aaa.mobile11;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtName, edtNumber ;
    Button btnInit, btnInsert, btnSelect, btnUpdate, btnDelete;
    ListView edtNameResult, edtNumberResult;
    MyDBHelper myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);
        edtNumber = findViewById(R.id.edtNumber);
        edtNameResult = findViewById(R.id.edtNameResult);
        edtNumberResult = findViewById(R.id.edtNumberResult);

        btnInit = findViewById(R.id.btnInit);
        btnInsert = findViewById(R.id.btnInsert);
        btnSelect = findViewById(R.id.btnSelect);

        btnDelete = findViewById(R.id.btnDelete);
        btnUpdate = findViewById(R.id.btnUpdate);


        myDBHelper = new MyDBHelper(this);

        btnInit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                myDBHelper.onUpgrade(sqlDB, 1, 2);
                Log.d("sqlite3DDL", "@@ DDL 호출 성공 @@");
                sqlDB.close();
            }
        }); // 초기화

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                String name = edtName.getText().toString();
                String number = edtNumber.getText().toString();
                sqlDB.execSQL("insert into groupTBL2 values ('" + name + "', '" + number + "');");
                Log.d("sqlite3DML", "@@ 데이터 삽입 성공 @@");
                sqlDB.close();
                Log.d("sqlite3DML", "@@ 데이터베이스 closed @@");
            }
        }); // 데이터 넣기

        //조회
        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                String name = edtName.getText().toString();
                String sql = "select * from groupTBL2 where gName = '" + name + "'";
                //String sql = "select * from groupTBL2";
                Cursor cursor = sqlDB.rawQuery(sql, null);

                // cursor.moveToNext는 한줄씩 옮기면서
                // 데이터가 있는지 없는지를 조회한다.
                //String result2 = "";
                //String result = "";
                ArrayList<String> nameList = new ArrayList<>();
                ArrayList<Integer> numberList = new ArrayList<>();
                while (cursor.moveToNext()) {
                    // cursor.moveToNext() 첫번째 행을 가르키면서 있는지 없는지를 체크한다.
                    // 있으면 true가 리턴된다
                    // 각 열에 있는 값들을 인덱스로 꺼내온다.
                    // 인덱스는 0번부터 시작된다
                    //result += cursor.getString(0) + "\r\n";
                    //result2 += cursor.getString(1) + "\r\n";
                    //Log.d("sqlite3DML", result);


                    nameList.add(cursor.getString(0));
                    numberList.add(cursor.getInt(1));


                    //edtNameResult.setText(result);
                    //edtNumberResult.setText(result2);

                } // while end
                //Log.d("sqlite3DML", result2);

                cursor.close();
                sqlDB.close();
                //리스트 뷰
                ArrayAdapter<String> nameAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, nameList);
                ArrayAdapter<Integer> numberAdapter = new ArrayAdapter<Integer>(getApplicationContext(), android.R.layout.simple_list_item_1, numberList);
                edtNameResult.setAdapter(nameAdapter);
                edtNumberResult.setAdapter(numberAdapter);


            }
        }); // 데이터 읽어오기

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edtName.getText().toString();
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                sqlDB.execSQL("DELETE FROM groupTBL2 WHERE gName = '" + name + "';");
                sqlDB.close();
                Log.d("sqlite3DML", "@@ 데이터 삭제 성공 @@");

            }
        });


        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = edtNumber.getText().toString();
                String name = edtName.getText().toString();
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();

                sqlDB.execSQL("update groupTBL2 set gNumber = '" + number + "' where gName = '" + name + "';");
                Log.d("sqlite3DML", "@@ 데이터 수정 성공 @@");
                sqlDB.close();

            }
        });


    }
}