package com.aaa.mobile11;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;


// 추상 클래스라서 상속 받아서 쓴다
public class MyDBHelper extends SQLiteOpenHelper {

    // 생성자를 만들어주어야 한다.
    // 생성자는 입력값이 있어야한다
    public MyDBHelper(@Nullable Context context) {
        super(context, "groupDB2", null, 1);
        Log.d("sqlite3DDL", "@@ 데이터베이스 생성 성공함 @@");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    db.execSQL("CREATE TABLE groupTBL2 (gName char(20), gNumber INTEGER);");
        Log.d("sqlite3DDL", "@@ TABLE 생성 성공 @@");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS groupTBL2");
        Log.d("sqlite3DDL", "@@ DROP TABLE 성공 @@");
        onCreate(db);
    }
}
